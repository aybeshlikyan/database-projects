SELECT 
    dob
FROM 
    Actor
WHERE
    id=65793
;